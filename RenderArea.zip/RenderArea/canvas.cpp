#include "canvas.h"

Canvas::Canvas(QWidget *parent)
    : QWidget{parent}
{
    numShapes = 0;
    setBackgroundRole(QPalette::Base);
    setAutoFillBackground(true);
}

void Canvas::paintEvent(QPaintEvent*)
{
    for(int i = 0; i < shapeVec.size(); i++)
    {
        shapeVec[i]->sketch(this);
    }
}

Vector<Shape*>& Canvas::getShape()
{
    return shapeVec;
}

void Canvas::addShape(Shape* insertShape)
{
    shapeVec.push_back(insertShape);
    numShapes++;
}

void Canvas::deleteShape(int removeIndex)
{
    Vector<Shape*>::iterator i;
    for(i = shapeVec.begin(); i < shapeVec.end(); i++)
    {
        if((*i)->getID() = removeIndex)
        {
            shapeVec.erase(i);
            numShapes--;
            break;
        }
    }
}

void Canvas::shapeMove(int moveIndex, int moveCoord, int x, int y)
{
    QPoint moveTo(x,y);
    for(int i = 0; i < shapeVec.size(); i++)
    {
        if(shapeVec[i]->getID() = moveIndex)
        {
            shapeVec[i]->move(moveTo);
            break;
        }
    }
}

int Canvas::getNumShapes()
{
    return numShapes;
}

QSize Canvas::sizeHint() const
{
    return QSize(1000, 500);
}

QSize Canvas::minimumSizeHint() const
{
    return QSize(1000, 500);
}

int Canvas::getSize()
{
    return shapeVec.size();
}

Shape::ShapeType Canvas::getShapeType(QString shapeQStr)
{
    if(shapeQStr == "Line")
    {
        return Shape::ShapeType::Line;
    }
    else if(shapeQStr == "Polyline")
    {
        return Shape::ShapeType::Polyline;
    }
    else if(shapeQStr == "Polygon")
    {
        return Shape::ShapeType::Polygon;
    }
    else if(shapeQStr == "Rectangle")
    {
        return Shape::ShapeType::Rectangle;
    }
    else if(shapeQStr == "Square")
    {
        return Shape::ShapeType::Square;
    }
    else if(shapeQStr == "Ellipse")
    {
        return Shape::ShapeType::Ellipse;
    }
    else if(shapeQStr == "Circle")
    {
        return Shape::ShapeType::Circle;
    }
    else
    {
        return Shape::ShapeType::Text;
    }
}

Qt::GlobalColor Canvas::getColor(QString color)
{
    if(color == "Red")
    {
        return Qt::red;
    }
    else if(color == "Green")
    {
        return Qt::green;
    }
    else if(color == "Blue")
    {
        return Qt::blue;
    }
    else if(color == "Yellow")
    {
        return Qt::yellow;
    }
    else if(color == "White")
    {
        return Qt::white;
    }
    else if(color == "Black")
    {
        return Qt::black;
    }
    else
    {
        return Qt::gray;
    }
}

Qt::PenCapStyle Canvas::getPenCapStyle(QString penCap)
{
    if(penCap == "FlatCap")
    {
        return Qt::FlatCap;
    }
    else if(penCap == "RoundCap")
    {
        return Qt::RoundCap;
    }
    else
    {
        return Qt::SquareCap;
    }
}

Qt::PenStyle Canvas::getPenStyle(QString penStyle)
{
    if(penStyle == "NoPen")
    {
        return Qt::NoPen;
    }
    else if(penStyle == "SolidLine")
    {
        return Qt::SolidLine;
    }
    else if(penStyle == "DashedLine")
    {
        return Qt::DashLine;
    }
    else if(penStyle == "DottedLine")
    {
        return Qt::DotLine;
    }
    else if(penStyle == "DashedDottedLine")
    {
        return Qt::DashDotLine;
    }
    else
    {
        return Qt::DashDotDotLine;
    }
}

Qt::PenJoinStyle Canvas::getPenJointStyle(QString penJointStyle)
{
    if(penJointStyle == "BevelJoin")
    {
        return Qt::BevelJoin;
    }
    else if(penJointStyle == "MiterJoin")
    {
        return Qt::MiterJoin;
    }
    else
    {
        return Qt::RoundJoin;
    }
}

Qt::BrushStyle Canvas::getBrushStyle(QString brushStyle)
{
    if(brushStyle == "Solid")
    {
        return Qt::SolidPattern;
    }
    else if(brushStyle == "Hor")
    {
        return Qt::HorPattern;
    }
    else if(brushStyle == "Ver")
    {
        return Qt::VerPattern;
    }
    else
    {
        return Qt::NoBrush;
    }
}

Qt::AlignmentFlag Canvas::getFlag(QString flag)
{
    if(flag == "Left")
    {
        return Qt::AlignLeft;
    }
    else if(flag == "Right")
    {
        return Qt::AlignRight;
    }
    else if(flag == "Top")
    {
        return Qt::AlignTop;
    }
    else if(flag == "Bottom")
    {
        return Qt::AlignBottom;
    }
    else
    {
        return Qt::AlignCenter;
    }
}

QFont::Style Canvas::getFontStyle(QString fontStyle)
{
    if(fontStyle == "Normal")
    {
        return QFont::StyleNormal;
    }
    else if(fontStyle == "Oblique")
    {
        return QFont::StyleOblique;
    }
    else
    {
        return QFont::StyleItalic;
    }
}

QFont::Weight Canvas::getFontWeight(QString fontWeight)
{
    if(fontWeight == "Normal")
    {
        return QFont::Normal;
    }
    else if(fontWeight == "Bold")
    {
        return QFont::Bold;
    }
    else if(fontWeight == "Light")
    {
        return QFont::Light;
    }
    else
    {
        return QFont::Thin;
    }
}

