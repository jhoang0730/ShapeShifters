#include "vector.h"

Vector::Vector()
{

}
