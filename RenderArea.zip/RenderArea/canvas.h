#ifndef CANVAS_H
#define CANVAS_H

#include <QWidget>
#include <QFile>
#include <QTextStream>
#include "shape.h"
#include "vector.h"
#include <QPaintEvent>
#include <QMessageBox>
#include <QCoreApplication>
#include <QDir>

class Canvas : public QWidget
{
    Q_OBJECT

private:
    //const QImage canvas;
    vector<Shape*> shapeVec;
    int numShapes;

    QString getStringColor(QColor color);
    QString getStringPen(Qt::PenCapStyle penCap);
    QString getStringPenStyle(Qt::PenStyle styple);
    QString getStringJointStyle(Qt::PenJoinStyle jointStyle);
    QString getStringBrush(Qt::BrushStyle brush);
    QString getStringFlag(Qt::AlignmentFlag flag);
    QString getStringFontStyle(QFont::Style fontStyle);
    QString getStringFontWeight(int weight);

    Shape::ShapeType  getShapeType(QString shapeType);
    Qt::GlobalColor   getColor(QString color);
    Qt::PenCapStyle   getPenCapStyle(QString penCap);
    Qt::PenStyle      getPenStyle(QString penStyle);
    Qt::PenJoinStyle  getPenJointStyle(QString jointStyle);
    Qt::BrushStyle    getBrushStyle(QString brush);
    Qt::AlignmentFlag getFlag(QString flag);
    QFont::Style      getFontStyle(QString fontStyle);
    QFont::Weight     getFontWeight(QString weight);

public:
    explicit Canvas(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *event) override;
    QSize sizeHint() const override;
    QSize minimumSizeHint() const override;
    Vector<Shape*>& getShape();

    void addShape(Shape* insertShape);

    int getSize();
    int getNumShapes();

    void deleteShape(int removeIndex);
    void shapeMove(int moveIndex, int moveCoord, int x, int y);

signals:

};

#endif // CANVAS_H
