#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_renderButton_clicked()
{
    QString shapeType  = ui->ShapeCBox->currentText();
    QString penColor   = ui->PenColorCBox->currentText();
    QString penStyle   = ui->PenStyleCBox->currentText();
    QString penCap     = ui->PenCapCBox->currentText();
    QString joinStyle  = ui->JoinStyleCBox->currentText();
    QString brushColor = ui->BrushColorCBox->currentText();
    QString brushStyle = ui->BrushStyleCBox->currentText();
    QString textRender = ui->TextLineEdit->text();
    QString textColor  = ui->TextColorCBox->currentText();
    QString textAlign  = ui->TextAlignCBox->currentText();
    bool    ok         = true;
    int     textSize   = ui->TextSizeCBox->currentText().toInt(&ok);
    QString textFont   = ui->TextFontCbox->currentText();
    QString textFontStyle = ui->TextStyleCBox->currentText();
    QString textFontWeight = ui->TextWeightCBox->currentText();
}

